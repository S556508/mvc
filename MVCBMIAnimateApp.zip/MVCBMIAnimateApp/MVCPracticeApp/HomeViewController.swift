//
//  ViewController.swift
//  MVCPracticeApp
//
//  Created by Kshatriya,Srivyshnavi on 4/3/23.
//

import UIKit

class HomeViewController: UIViewController {
    
    @IBOutlet weak var label1: UITextField!
    
    
    @IBOutlet weak var label2: UITextField!
    
    @IBOutlet weak var label3: UITextField!
    
    var img = ""
    var display = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func button1(_ sender: UIButton) {
        //reading the height in feet and storing it in a variable heightFT
                let heighFT = Double(label1.text!) ?? 0.0
                
                //reading the height in inches and storing it in a variable heightInches
                
                let heightInches = Double(label2.text!) ?? 0.0
                
                //converting the height in feet to inches to calculate the total height in inches
                
                let height = (heighFT*12) + heightInches
                
                //reading the weight in lbs and storing it in a variable weight
                
                let weight = Double(label3.text!) ?? 0.0
                
                // calculating the BodyMassIndex based on the givn formula
                
                let bm = (703*weight) / (height*height)
                
                //rounding up the BMI to one decimal value
                
                let BMI = round(bm * 10)/10.0
                
                //Displaying the image and the output based on the BMI
                
                if(BMI <= 18.5){
                    img = "underWeight"
                    display = "Your Body Mass Index is \(BMI).\nThis is considered UnderWeight."
                }
                else if(BMI >= 18.6 && BMI
                          <= 24.9){
                    img = "normal"
                    display = "Your Body Mass Index is \(BMI).\nThis is considered Normal👍."
                }
                else if( BMI >= 25 && BMI <= 29.9 ){
                   img = "overWeight"
                    display = "Your Body Mass Index is \(BMI).\nThis is considered OverWeight."
                }
                else if(BMI >= 30.0){
                    img = "obese"
                    display = "Your Body Mass Index is \(BMI).\nThis is considered Obesity."
                }
                
                
            }
          
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "ResultSegue"{
            let destination = segue.destination as! ResultViewController
            destination.destimg = img
            destination.destdisplay = display
        }
    }
        }
    


