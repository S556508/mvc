//
//  ResultViewController.swift
//  MVCPracticeApp
//
//  Created by Kshatriya,Srivyshnavi on 4/3/23.
//

import UIKit

class ResultViewController: UIViewController {
    
    var destimg = ""
    var destdisplay = ""

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        image1.image = UIImage(named: destimg)
        resultLabel.text = destdisplay
    }
    
    
    @IBOutlet weak var image1: UIImageView!
    
    @IBOutlet weak var resultLabel: UILabel!
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    
    
    
    @IBAction func shakeMeButton(_ sender: UIButton) {
        var width = image1.frame.width
                
                width += 40
                
                var height = image1.frame.height
                
                height = height + 40
                
                var x  =  image1.frame.origin.x-20
                
                
                var y = image1.frame.origin.y-20
                
                var largeFrame = CGRect(x: x, y: y, width: width, height: height)
                
                UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 50, animations: {
                    self.image1.frame = largeFrame
                })
    }
    

}
